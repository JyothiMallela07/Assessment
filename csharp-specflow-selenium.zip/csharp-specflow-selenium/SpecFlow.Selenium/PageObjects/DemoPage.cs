using System;
using System.Collections.Generic;
using System.Linq;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Xunit;

namespace SpecFlow.Selenium.PageObjects
{
    public class DemoPage : PageObject
    {
        private readonly IWebDriver _driver;

        public DemoPage(IWebDriver driver) : base(driver)
        {
            _driver = driver;
        }

        public static By careers = By.XPath("//div[@class='footer - links']//a[text()='Careers']");
        public static By keywordSearch = By.CssSelector("input[type='search']");
        public static By submit = By.CssSelector("button.search-form__submit");
        public static By jobTitle = By.XPath("(//section[@id='search-results-list']/ul//a/h2)[1]");
        public static By jobLocation = By.XPath("(//span[@class='job - location'])[1]");
        public static By jobDatePosted = By.XPath("(//span[@class='job-date-posted'])[1]");
        public static By applyNow = By.XPath("(//a[normalize-space(text())='Apply Now'])[2]");

        public static By appliedJobTitle = By.CssSelector("span.jobTitle.job-detail-title");
        public static By returnToJobSearch = By.XPath("//span[text()='Return to Job Search']/parent::button");


        public void SelectResult(string expResult)
        {
            _driver.FindElement(jobTitle).Click();
        }


 
     
        public void clickOnCareers()
        {
            _driver.FindElement(careers).Click();
        }
        public void SearchFor(string searchText)
        {
            _driver.FindElement(keywordSearch).Clear();
            _driver.FindElement(keywordSearch).SendKeys(searchText);
           
        }
        public void clickOnSubmit()
        {
            _driver.FindElement(submit).Click();
        }
        public Boolean isSearchResultsDisplayed()
        {
            return _driver.FindElement(jobTitle).Displayed;
        }
        public String getJobTitle()
        {
            return _driver.FindElement(jobTitle).Text;
        }
        public void selectFirstJob()
        {
             _driver.FindElement(jobTitle).Click();
        }
        public String getJobLocation()
        {
            return _driver.FindElement(jobLocation).Text;
        }
        public String getJobPostedDate()
        {
            return _driver.FindElement(jobDatePosted).Text;
        }
        public void clickOnApplyNow()
        {
            _driver.FindElement(applyNow).Click();
        }
        public String getAppliedJobTitle()
        {
            return _driver.FindElement(appliedJobTitle).Text;
        }

        public String verifyAppliedJob(String jobTitle)
        {
            _driver.FindElement(appliedJobTitle).Text.Should().Be(jobTitle);
        }
        public void clickOnReturnToJobSearch()
        {
            _driver.FindElement(returnToJobSearch).Click();
        }

    }
}