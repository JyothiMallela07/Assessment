﻿using OpenQA.Selenium;
using SpecFlow.Selenium.PageObjects;
using TechTalk.SpecFlow;

namespace SpecFlow.Selenium.StepDefinitions
{
	[Binding]
	public class StepDefinitions
	{
		private readonly DemoPage _page;
		public static string jobTitle, place, jobLocation;
		
		public StepDefinitions(IWebDriver driver)
		{
			_page = new DemoPage(driver);
		}
		
		[Given(@"I am on ""(.*)""")]
		public void GivenIAmOn(string url)
		{
			_page.Navigate(url);
		}
		
		// demonstrates running the same steps but for scenarios with different tags
		[Given(@"I am on ""(.*)"""), Scope(Tag = "web")]
		public void GivenOn(string url)
		{
			_page.Navigate(url);
		}

		[When(@"I click on Carreers link")]
		public void WhenIClickONCareersLink()
		{
			_page.clickOnCareers();
		}
        
		[When(@"Enter search term ""(.*)""")]
		public void WhenEnterSearchTerm(string job)
		{
			_page.SearchFor(job);
		}
        
		[When(@"Click on Submit button")]
		public void WhenIClickOnSubmitButton()
		{
			_page.clickOnSubmit();
		}
		[Then(@"Verify search results are displayed")]
		public void ThenVerifySearchResults()
		{
			_page.isSearchResultsDisplayed();
			jobTitle = _page.getJobTitle();
			jobLocation = _page.getJobLocation();
		}

		[When(@"I click on first result")]
		public void WhenIClickOnFirstResult()
		{
			_page.selectFirstJob();
		}

		[When(@"I click on Apply button")]
		public void WhenIClickOnApplyButton()
		{
			
			_page.clickOnApplyNow();
		}

		
		[Then(@"Verify applied job details")]
		public void ThenVerifyAppliedJobD()
		{
			_page.verifyAppliedJob(jobTitle);

		}

		

		[When(@"Click on return to Job Search")]
		public void WhenIClickOnReturnToJobSearch()
		{

			_page.clickOnReturnToJobSearch();
		}
	}
}